# MopedWerk – digitale Werkstatt für Moped-Schrauber (Kern-Version 0.1.0)

Native Android-App (Kotlin, Jetpack Compose, Material 3, Room, DataStore, WorkManager). Offline-First, alle Daten bleiben lokal.

> **Wichtiger Status:** Dieses Projekt wurde in einer Umgebung ohne Android SDK und ohne Zugriff auf
> Google-/Maven-Repositories geschrieben. Es wurde **noch nicht kompiliert, getestet oder als APK gebaut**.
> Rechne beim ersten Build mit kleineren Compiler-Korrekturen. Die Version 0.1.0 ist bewusst ein
> Kern-Stand, nicht der vollständige Funktionsumfang des Master-Prompts.

## Voraussetzungen
- Android Studio (Ladybug 2024.2 oder neuer) mit JDK 17 oder höher
- Android SDK Platform 35
- Internetzugang für den ersten Gradle-Sync

## Build & Installation
1. Ordner `MopedWerk` in Android Studio öffnen (**File → Open**). Der Gradle-Wrapper (`gradle-wrapper.properties`, Gradle 8.9) ist konfiguriert; falls `gradlew`/`gradle-wrapper.jar` fehlen, erzeugt Android Studio sie beim Sync, oder auf der Kommandozeile `gradle wrapper --gradle-version 8.9`.
2. Gradle-Sync abwarten.
3. Gerät/Emulator (Android 8.0 / API 26 oder neuer) wählen und **Run** drücken.
4. Debug-APK per Kommandozeile: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/`.
5. Unit-Tests: `./gradlew testDebugUnitTest`.

Den App-Namen änderst du zentral in `app/src/main/res/values/strings.xml` (`app_name`).

## Architektur
- `data/` – Room-Entities, DAOs, Datenbank, Repository (inkl. JSON-Export/-Import), Beispieldaten
- `domain/` – reine Logik ohne Android-Abhängigkeit: Fälligkeitsberechnung, Kostenrechnung, deutsche Formatierung (unit-getestet)
- `ui/` – Compose-Screens, Formulare, ein `AppViewModel`, Theme (Anthrazit/Schwarz/Weiß + Orange, Dark/Light)
- `work/` – `ReminderWorker` (täglich, WorkManager) für Wartungs-Benachrichtigungen
- Dependency Injection: bewusst einfacher manueller `AppContainer` statt Hilt (weniger Build-Risiko, leicht später durch Hilt ersetzbar)
- Navigation: untere Leiste mit Home, Garage, Schrauben, Teile, Profil

## Implementiert (Kern)
- Garage: mehrere Fahrzeuge anlegen/bearbeiten/löschen, Hauptfahrzeug, Archiv, Projektstatus, Detailseite mit Reitern
- Wartungsplaner: eigene Intervalle (km und/oder Monate), Status fällig/bald fällig/ok/kein Intervall, „Erledigt“ mit automatischem Tagebucheintrag und Kilometerstand-Update, tägliche Hintergrundprüfung mit Benachrichtigung
- Schrauber-Tagebuch: Einträge mit Kosten, Arbeitszeit, Teilen, Werkzeugen, Status, Problem/Lösung; Volltextsuche
- Ersatzteile: Kategorien, Status, Fahrzeugzuordnung, Dublettenhinweis, Kennzeichnung „Kompatibilität bestätigt / nicht bestätigt“
- Kosten: Summen pro Fahrzeug (Tagebuch + gekaufte Teile), geplante Teile, Ausgaben im Monat im Dashboard
- Dashboard, Einstellungen (Dark/Light, Erinnerungen), JSON-Export/-Import, Löschen aller Daten
- Beispieldaten beim ersten Start, überall mit „BEISPIEL“ gekennzeichnet
- Eingabevalidierung, Leer- und Ladezustände, deutsche Datums-/Zahlen-/Währungsformate

## Noch offen (nicht implementiert)
- Reparaturanleitungen mit abhakbaren Schritten
- Offline-Entscheidungsbaum zur Fehlerdiagnose
- Schrauber-KI (benötigt Backend/Proxy – API-Schlüssel gehören nie in die App)
- Werkzeugkiste, Wissensbereich
- Tuning-/Umbauplaner, Kostendiagramme, PDF-/CSV-Export
- Foto-Dokumentation, Bildvergleich, QR-Code-Profil
- Community, Teilefinder/Externe Suchlinks, Cloud-Sync
- Room-Migrationen (aktuell Schema-Version 1), automatisierte UI-/Instrumentationstests
- Dokumente und Rechnungen pro Fahrzeug, Betriebsstunden-basierte Wartung

## Datenschutz & Datenqualität
- Keine Konten, kein Tracking, keine Netzwerkzugriffe; einzige Berechtigung: Benachrichtigungen.
- Die App liefert **keine Herstellerdaten**. Wartungsintervalle und Teilekompatibilität trägst du selbst ein und kannst sie als „geprüft“ markieren.
- `allowBackup` ist ausgeschaltet; Datensicherung läuft über den JSON-Export.
