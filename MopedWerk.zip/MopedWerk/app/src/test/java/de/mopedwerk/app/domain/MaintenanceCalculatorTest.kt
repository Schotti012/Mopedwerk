package de.mopedwerk.app.domain

import de.mopedwerk.app.data.MaintenanceTask
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MaintenanceCalculatorTest {
    private val today = LocalDate.of(2026, 11, 1)

    private fun task(
        intervalKm: Int? = null, intervalMonths: Int? = null,
        lastKm: Int? = null, lastDate: LocalDate? = null
    ) = MaintenanceTask(
        vehicleId = 1, title = "Test", intervalKm = intervalKm, intervalMonths = intervalMonths,
        lastDoneKm = lastKm, lastDoneEpochDay = lastDate?.toEpochDay()
    )

    @Test fun ohneIntervall_istUnbekannt() {
        assertEquals(DueState.UNBEKANNT, MaintenanceCalculator.evaluate(task(), 1000, today).state)
    }

    @Test fun kmIntervall_ok() {
        val info = MaintenanceCalculator.evaluate(task(intervalKm = 3000, lastKm = 1000), 2000, today)
        assertEquals(DueState.OK, info.state)
        assertEquals(4000, info.nextDueKm)
        assertEquals(2000, info.remainingKm)
    }

    @Test fun kmIntervall_baldFaellig() {
        val info = MaintenanceCalculator.evaluate(task(intervalKm = 3000, lastKm = 1000), 3900, today)
        assertEquals(DueState.BALD_FAELLIG, info.state)
    }

    @Test fun kmIntervall_ueberfaellig() {
        val info = MaintenanceCalculator.evaluate(task(intervalKm = 3000, lastKm = 1000), 4100, today)
        assertEquals(DueState.UEBERFAELLIG, info.state)
        assertEquals(-100, info.remainingKm)
    }

    @Test fun zeitIntervall_ueberfaellig() {
        val info = MaintenanceCalculator.evaluate(
            task(intervalMonths = 12, lastDate = today.minusMonths(13)), 0, today
        )
        assertEquals(DueState.UEBERFAELLIG, info.state)
    }

    @Test fun zeitIntervall_baldFaellig() {
        val info = MaintenanceCalculator.evaluate(
            task(intervalMonths = 12, lastDate = today.minusMonths(12).plusDays(10)), 0, today
        )
        assertEquals(DueState.BALD_FAELLIG, info.state)
    }

    @Test fun intervallAberNieErledigt_istUnbekannt() {
        val info = MaintenanceCalculator.evaluate(task(intervalKm = 3000), 500, today)
        assertEquals(DueState.UNBEKANNT, info.state)
        assertNull(info.nextDueKm)
    }

    @Test fun ueberfaelligInEinerDimension_genuegt() {
        val info = MaintenanceCalculator.evaluate(
            task(intervalKm = 3000, intervalMonths = 6, lastKm = 1000, lastDate = today.minusMonths(7)), 1500, today
        )
        assertEquals(DueState.UEBERFAELLIG, info.state)
    }
}
