package de.mopedwerk.app.domain

import de.mopedwerk.app.data.JournalEntry
import de.mopedwerk.app.data.Part
import de.mopedwerk.app.data.PartStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CostAndFormatTest {
    private fun j(vehicle: Long, cents: Long) = JournalEntry(vehicleId = vehicle, epochDay = 0, title = "x", costCents = cents)
    private fun p(vehicle: Long?, cents: Long, qty: Int, status: PartStatus) =
        Part(vehicleId = vehicle, name = "t", priceCents = cents, quantity = qty, status = status)

    @Test fun gesamtkosten_proFahrzeug_summiertKorrekt() {
        val journal = listOf(j(1, 1000), j(1, 250), j(2, 9999))
        val parts = listOf(
            p(1, 450, 2, PartStatus.VERBAUT),   // 900 zählt
            p(1, 500, 1, PartStatus.GEPLANT),   // zählt nicht (geplant)
            p(2, 100, 1, PartStatus.VERBAUT)    // anderes Fahrzeug
        )
        assertEquals(1000L + 250L + 900L, CostCalculator.totalForVehicle(1, journal, parts))
        assertEquals(500L, CostCalculator.plannedForVehicle(1, parts))
    }

    @Test fun betrag_wirdMitKommaUndPunktGeparst() {
        assertEquals(1250L, Formatting.parseMoneyToCents("12,50"))
        assertEquals(1250L, Formatting.parseMoneyToCents("12.50"))
        assertEquals(123456L, Formatting.parseMoneyToCents("1.234,56"))
        assertEquals(0L, Formatting.parseMoneyToCents(""))
        assertNull(Formatting.parseMoneyToCents("abc"))
        assertNull(Formatting.parseMoneyToCents("-5"))
    }

    @Test fun datum_wirdDeutschGeparst() {
        val d = Formatting.parseDate("01.11.2026")!!
        assertEquals(2026, d.year)
        assertEquals(11, d.monthValue)
        assertNull(Formatting.parseDate("2026-11-01"))
        assertNull(Formatting.parseDate("31.02.2026"))
    }
}
