package de.mopedwerk.app.data

import java.time.LocalDate

/**
 * Beispieldaten für den ersten Start. Alle Datensätze tragen isSample = true und werden in der UI
 * als „Beispiel“ gekennzeichnet. Es sind bewusst KEINE Herstellerangaben enthalten: Wartungsintervalle
 * sind Platzhalter-Vorschläge ohne Verifizierung und müssen vom Nutzer aus dem Handbuch geprüft werden.
 */
object SampleData {
    suspend fun insertInto(repo: Repository, today: LocalDate = LocalDate.now()) {
        val vehicleId = repo.saveVehicle(
            Vehicle(
                brand = "Beispiel-Marke",
                model = "Beispiel-Moped",
                year = 1980,
                type = "Moped",
                displacementCcm = 50,
                mileageKm = 8200,
                status = VehicleStatus.IN_ARBEIT,
                isMain = true,
                notes = "Beispieldatensatz – bitte durch dein eigenes Fahrzeug ersetzen.",
                isSample = true
            )
        )
        val day = today.toEpochDay()
        repo.saveTask(
            MaintenanceTask(
                vehicleId = vehicleId, title = "Zündkerze prüfen",
                intervalKm = 3000, intervalMonths = 12,
                lastDoneKm = 6000, lastDoneEpochDay = day - 200,
                intervalVerified = false,
                notes = "Beispielintervall, nicht verifiziert. Bitte im Handbuch prüfen.",
                isSample = true
            )
        )
        repo.saveTask(
            MaintenanceTask(
                vehicleId = vehicleId, title = "Kette reinigen und schmieren",
                intervalKm = 500, lastDoneKm = 7900, lastDoneEpochDay = day - 40,
                intervalVerified = false, isSample = true
            )
        )
        repo.saveTask(
            MaintenanceTask(
                vehicleId = vehicleId, title = "Vergaser reinigen",
                notes = "Kein Intervall hinterlegt.", isSample = true
            )
        )
        repo.saveJournal(
            JournalEntry(
                vehicleId = vehicleId, epochDay = day - 30, mileageKm = 8100,
                title = "Vergaser gereinigt",
                description = "Beispieleintrag: Vergaser zerlegt und gereinigt.",
                partsUsed = "Dichtsatz", toolsUsed = "Schraubendreher, Reiniger",
                workMinutes = 90, costCents = 1250,
                problemAndSolution = "Moped lief unrund im Standgas – nach der Reinigung wieder ruhig.",
                isSample = true
            )
        )
        repo.savePart(
            Part(
                vehicleId = vehicleId, name = "Zündkerze (Beispiel)", category = PartCategory.ZUENDUNG,
                priceCents = 450, quantity = 2, status = PartStatus.GEPLANT,
                compatibilityConfirmed = false,
                notes = "Kompatibilität nicht geprüft.", isSample = true
            )
        )
    }
}
