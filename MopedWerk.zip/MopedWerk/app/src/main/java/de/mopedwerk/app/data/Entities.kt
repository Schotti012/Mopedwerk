package de.mopedwerk.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/** Projektstatus eines Fahrzeugs. */
enum class VehicleStatus(val label: String) {
    FAHRBEREIT("Fahrbereit"),
    IN_ARBEIT("In Arbeit"),
    RESTAURATION("Restaurationsprojekt"),
    STILLGELEGT("Stillgelegt")
}

enum class JournalStatus(val label: String) {
    BEGONNEN("Begonnen"),
    PAUSIERT("Pausiert"),
    ABGESCHLOSSEN("Abgeschlossen")
}

enum class PartStatus(val label: String) {
    GEPLANT("Geplant"),
    BESTELLT("Bestellt"),
    GELIEFERT("Geliefert"),
    VERBAUT("Verbaut"),
    AUSGEBAUT("Ausgebaut")
}

enum class PartCategory(val label: String) {
    MOTOR("Motor"),
    VERGASER("Vergaser"),
    ZUENDUNG("Zündung"),
    KUPPLUNG("Kupplung"),
    GETRIEBE("Getriebe"),
    AUSPUFF("Auspuff"),
    ELEKTRIK("Elektrik"),
    BREMSEN("Bremsen"),
    FAHRWERK("Fahrwerk"),
    RAEDER_REIFEN("Räder und Reifen"),
    KAROSSERIE("Karosserie"),
    VERBRAUCH("Werkzeuge und Verbrauchsmaterial")
}

@Entity(tableName = "vehicles")
@Serializable
data class Vehicle(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val brand: String,
    val model: String,
    val year: Int? = null,
    val type: String = "Moped",
    val displacementCcm: Int? = null,
    val vin: String = "",
    val engineCode: String = "",
    val mileageKm: Int = 0,
    val operatingHours: Int = 0,
    val status: VehicleStatus = VehicleStatus.FAHRBEREIT,
    val isMain: Boolean = false,
    val isArchived: Boolean = false,
    val purchasePriceCents: Long? = null,
    val estimatedValueCents: Long? = null,
    val notes: String = "",
    /** true = Beispieldatensatz, wird in der UI als solcher gekennzeichnet. */
    val isSample: Boolean = false
) {
    val displayName: String get() = "$brand $model".trim()
}

/**
 * Wartungspunkt. Intervalle sind immer vom Nutzer eingetragen – die App liefert
 * keine Herstellerwerte. [intervalVerified] markiert, ob der Nutzer das Intervall
 * aus einer verlässlichen Quelle (Handbuch) übernommen hat.
 */
@Entity(
    tableName = "maintenance_tasks",
    foreignKeys = [ForeignKey(Vehicle::class, ["id"], ["vehicleId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("vehicleId")]
)
@Serializable
data class MaintenanceTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val title: String,
    val intervalKm: Int? = null,
    val intervalMonths: Int? = null,
    val lastDoneKm: Int? = null,
    val lastDoneEpochDay: Long? = null,
    val intervalVerified: Boolean = false,
    val notes: String = "",
    val isSample: Boolean = false
)

@Entity(
    tableName = "journal_entries",
    foreignKeys = [ForeignKey(Vehicle::class, ["id"], ["vehicleId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("vehicleId")]
)
@Serializable
data class JournalEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val epochDay: Long,
    val mileageKm: Int? = null,
    val title: String,
    val description: String = "",
    val partsUsed: String = "",
    val toolsUsed: String = "",
    val workMinutes: Int = 0,
    val costCents: Long = 0,
    val status: JournalStatus = JournalStatus.ABGESCHLOSSEN,
    val problemAndSolution: String = "",
    val isSample: Boolean = false
)

@Entity(
    tableName = "parts",
    foreignKeys = [ForeignKey(Vehicle::class, ["id"], ["vehicleId"], onDelete = ForeignKey.SET_NULL)],
    indices = [Index("vehicleId")]
)
@Serializable
data class Part(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long? = null,
    val name: String,
    val category: PartCategory = PartCategory.MOTOR,
    val manufacturer: String = "",
    val partNumber: String = "",
    val priceCents: Long = 0,
    val shop: String = "",
    val shopUrl: String = "",
    val quantity: Int = 1,
    val status: PartStatus = PartStatus.GEPLANT,
    /** false = Kompatibilität nur vermutet / ungeprüft. */
    val compatibilityConfirmed: Boolean = false,
    val notes: String = "",
    val isSample: Boolean = false
)
