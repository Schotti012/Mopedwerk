package de.mopedwerk.app.domain

import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle
import java.util.Locale

object Formatting {
    private val de = Locale.GERMANY
    private val dateFormatter = DateTimeFormatter.ofPattern("dd.MM.uuuu", de).withResolverStyle(ResolverStyle.STRICT)

    fun money(cents: Long): String = NumberFormat.getCurrencyInstance(de).format(cents / 100.0)

    fun date(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).format(dateFormatter)

    fun date(date: LocalDate): String = date.format(dateFormatter)

    fun km(km: Int): String = NumberFormat.getIntegerInstance(de).format(km) + " km"

    /** Parst "12,50" oder "12.50" zu Cent. Liefert null bei ungültiger Eingabe. */
    fun parseMoneyToCents(input: String): Long? {
        val s = input.trim().replace("€", "").replace(" ", "")
        if (s.isEmpty()) return 0L
        val normalized = if (s.contains(',')) s.replace(".", "").replace(',', '.') else s
        val value = normalized.toDoubleOrNull() ?: return null
        if (value < 0) return null
        return Math.round(value * 100)
    }

    /** Parst "dd.MM.yyyy" zu LocalDate, sonst null. */
    fun parseDate(input: String): LocalDate? =
        try { LocalDate.parse(input.trim(), dateFormatter) } catch (e: Exception) { null }
}
