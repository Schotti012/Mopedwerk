package de.mopedwerk.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import de.mopedwerk.app.data.JournalEntry
import de.mopedwerk.app.data.Part
import de.mopedwerk.app.domain.CostCalculator
import de.mopedwerk.app.domain.Formatting

/** Bereich „Schrauben“ – in dieser Version: Schrauber-Tagebuch mit Suche und Filter. */
@Composable
fun JournalList(vm: AppViewModel, vehicleFilter: Long? = null, showTitle: Boolean = true) {
    val all by vm.journal.collectAsState()
    val vehicles by vm.vehicles.collectAsState()
    val archived by vm.archivedVehicles.collectAsState()
    val query by vm.searchQuery.collectAsState()
    val names = (vehicles.orEmpty() + archived).associate { it.id to it.displayName }
    val entries = if (vehicleFilter == null) all else all.filter { it.vehicleId == vehicleFilter }
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<JournalEntry?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (showTitle) ScreenTitle("Schrauber-Tagebuch")
        OutlinedTextField(
            value = query, onValueChange = { vm.searchQuery.value = it },
            label = { Text("Einträge durchsuchen") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth().height(52.dp).padding(top = 8.dp)) {
            Text("Neuer Eintrag")
        }
        when {
            entries.isEmpty() && query.isNotBlank() -> EmptyState("Keine Treffer", "Für „$query“ wurde nichts gefunden.")
            entries.isEmpty() -> EmptyState("Noch keine Einträge", "Dokumentiere deine erste Reparatur.")
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 12.dp)) {
                items(entries, key = { it.id }) { e ->
                    MwCard {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(e.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f, fill = false))
                            if (e.isSample) SampleBadge()
                        }
                        Text(
                            "${Formatting.date(e.epochDay)} · ${names[e.vehicleId] ?: "Unbekanntes Fahrzeug"} · ${e.status.label}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        e.mileageKm?.let { LabeledRow("Kilometerstand", Formatting.km(it)) }
                        if (e.costCents > 0) LabeledRow("Kosten", Formatting.money(e.costCents))
                        if (e.workMinutes > 0) LabeledRow("Arbeitszeit", "${e.workMinutes} min")
                        if (e.description.isNotBlank()) Text(e.description, modifier = Modifier.padding(top = 4.dp))
                        if (e.problemAndSolution.isNotBlank()) Text("Problem/Lösung: ${e.problemAndSolution}", modifier = Modifier.padding(top = 4.dp))
                        Row {
                            TextButton(onClick = { editing = e }) { Text("Bearbeiten") }
                            TextButton(onClick = { vm.deleteJournal(e) }) { Text("Löschen") }
                        }
                    }
                }
            }
        }
    }

    val vehicleList = vehicles.orEmpty()
    if (adding) JournalForm(vehicleList, vehicleFilter, null, { adding = false }) { vm.saveJournal(it) }
    editing?.let { e -> JournalForm(vehicleList, vehicleFilter, e, { editing = null }) { vm.saveJournal(it) } }
}

@Composable
fun PartsList(vm: AppViewModel, vehicleFilter: Long? = null, showTitle: Boolean = true) {
    val allParts by vm.parts.collectAsState()
    val vehicles by vm.vehicles.collectAsState()
    val archived by vm.archivedVehicles.collectAsState()
    val names = (vehicles.orEmpty() + archived).associate { it.id to it.displayName }
    val parts = if (vehicleFilter == null) allParts else allParts.filter { it.vehicleId == vehicleFilter }
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Part?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (showTitle) ScreenTitle("Ersatzteile")
        Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Teil hinzufügen") }
        if (parts.isEmpty()) {
            EmptyState("Noch keine Teile", "Lege Ersatzteile, Wunschlisten-Teile und Bestellungen an.")
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 12.dp)) {
            items(parts, key = { it.id }) { p ->
                MwCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f, fill = false))
                        if (p.isSample) SampleBadge()
                    }
                    Text("${p.category.label} · ${p.status.label}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    p.vehicleId?.let { Text("Fahrzeug: ${names[it] ?: "—"}") }
                    if (p.manufacturer.isNotBlank() || p.partNumber.isNotBlank())
                        Text(listOf(p.manufacturer, p.partNumber).filter { it.isNotBlank() }.joinToString(" · "))
                    LabeledRow("Preis × Menge", "${Formatting.money(p.priceCents)} × ${p.quantity} = ${Formatting.money(CostCalculator.partCostCents(p))}")
                    Text(
                        if (p.compatibilityConfirmed) "Kompatibilität: bestätigt (vom Nutzer)" else "Kompatibilität: nicht bestätigt / nur vermutet",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (p.compatibilityConfirmed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row {
                        TextButton(onClick = { editing = p }) { Text("Bearbeiten") }
                        TextButton(onClick = { vm.deletePart(p) }) { Text("Löschen") }
                    }
                }
            }
        }
    }

    val vehicleList = vehicles.orEmpty()
    if (adding) PartForm(vehicleList, null, { adding = false }) {
        vm.savePart(if (vehicleFilter != null && it.vehicleId == null) it.copy(vehicleId = vehicleFilter) else it)
    }
    editing?.let { p -> PartForm(vehicleList, p, { editing = null }) { vm.savePart(it) } }
}
