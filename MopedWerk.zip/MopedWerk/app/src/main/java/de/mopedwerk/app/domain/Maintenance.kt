package de.mopedwerk.app.domain

import de.mopedwerk.app.data.MaintenanceTask
import java.time.LocalDate
import java.time.temporal.ChronoUnit

enum class DueState(val label: String) {
    UEBERFAELLIG("Überfällig"),
    BALD_FAELLIG("Bald fällig"),
    OK("In Ordnung"),
    UNBEKANNT("Kein Intervall hinterlegt")
}

data class DueInfo(
    val state: DueState,
    /** Verbleibende Kilometer (negativ = überfällig), null wenn kein km-Intervall. */
    val remainingKm: Int?,
    /** Verbleibende Tage (negativ = überfällig), null wenn kein Zeitintervall. */
    val remainingDays: Long?,
    val nextDueKm: Int?,
    val nextDueDate: LocalDate?
)

object MaintenanceCalculator {
    const val SOON_KM = 200
    const val SOON_DAYS = 30L

    /**
     * Berechnet den Fälligkeitsstatus. Ist weder Kilometer- noch Zeitintervall
     * hinterlegt, wird [DueState.UNBEKANNT] geliefert – es werden keine Werte erfunden.
     * Wurde eine Wartung noch nie erledigt, gilt sie als nicht berechenbar für diese Dimension.
     */
    fun evaluate(task: MaintenanceTask, currentKm: Int, today: LocalDate): DueInfo {
        val nextKm = if (task.intervalKm != null && task.lastDoneKm != null)
            task.lastDoneKm + task.intervalKm else null
        val nextDate = if (task.intervalMonths != null && task.lastDoneEpochDay != null)
            LocalDate.ofEpochDay(task.lastDoneEpochDay).plusMonths(task.intervalMonths.toLong()) else null

        val remKm = nextKm?.let { it - currentKm }
        val remDays = nextDate?.let { ChronoUnit.DAYS.between(today, it) }

        val hasInterval = task.intervalKm != null || task.intervalMonths != null
        val state = when {
            !hasInterval -> DueState.UNBEKANNT
            (remKm != null && remKm < 0) || (remDays != null && remDays < 0) -> DueState.UEBERFAELLIG
            (remKm != null && remKm <= SOON_KM) || (remDays != null && remDays <= SOON_DAYS) -> DueState.BALD_FAELLIG
            remKm == null && remDays == null -> DueState.UNBEKANNT // Intervall da, aber noch nie erledigt
            else -> DueState.OK
        }
        return DueInfo(state, remKm, remDays, nextKm, nextDate)
    }
}
