package de.mopedwerk.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import de.mopedwerk.app.AppContainer
import de.mopedwerk.app.data.JournalEntry
import de.mopedwerk.app.data.MaintenanceTask
import de.mopedwerk.app.data.Part
import de.mopedwerk.app.data.Vehicle
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(private val container: AppContainer) : ViewModel() {
    private val repo = container.repository

    // null = noch am Laden; leere Liste = wirklich leer
    val vehicles: StateFlow<List<Vehicle>?> =
        repo.observeVehicles().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val archivedVehicles: StateFlow<List<Vehicle>> =
        repo.observeVehicles(archived = true).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tasks: StateFlow<List<MaintenanceTask>> =
        repo.observeAllTasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val parts: StateFlow<List<Part>> =
        repo.observeParts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchQuery = MutableStateFlow("")

    @OptIn(ExperimentalCoroutinesApi::class)
    val journal: StateFlow<List<JournalEntry>> = searchQuery.flatMapLatest { q ->
        if (q.isBlank()) repo.observeJournal() else repo.searchJournal(q.trim())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Gesamtes Tagebuch (ungefiltert) für Kostenberechnung und Fahrzeughistorie. */
    val allJournal: StateFlow<List<JournalEntry>> =
        repo.observeJournal().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val darkTheme: StateFlow<Boolean> =
        container.darkTheme.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val remindersEnabled: StateFlow<Boolean> =
        container.remindersEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, true)

    /** Einmalige Nachrichten für Snackbar. */
    val message = MutableStateFlow<String?>(null)

    private fun run(errorText: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            try { block() } catch (e: Exception) { message.value = "$errorText: ${e.message ?: "Unbekannter Fehler"}" }
        }
    }

    fun saveVehicle(v: Vehicle) = run("Fahrzeug konnte nicht gespeichert werden") {
        repo.saveVehicle(v); message.value = "Fahrzeug gespeichert"
    }
    fun setMain(id: Long) = run("Hauptfahrzeug konnte nicht gesetzt werden") { repo.setMainVehicle(id) }
    fun archive(v: Vehicle, archived: Boolean) = run("Archivieren fehlgeschlagen") {
        repo.setArchived(v, archived)
        message.value = if (archived) "Fahrzeug archiviert" else "Fahrzeug wiederhergestellt"
    }
    fun deleteVehicle(v: Vehicle) = run("Löschen fehlgeschlagen") { repo.deleteVehicle(v); message.value = "Fahrzeug gelöscht" }

    fun saveTask(t: MaintenanceTask) = run("Wartung konnte nicht gespeichert werden") { repo.saveTask(t) }
    fun deleteTask(t: MaintenanceTask) = run("Löschen fehlgeschlagen") { repo.deleteTask(t) }
    fun completeTask(t: MaintenanceTask, km: Int, epochDay: Long, costCents: Long) =
        run("Wartung konnte nicht abgeschlossen werden") {
            repo.completeTask(t, km, epochDay, costCents)
            message.value = "Wartung erledigt und in die Historie eingetragen"
        }

    fun saveJournal(e: JournalEntry) = run("Eintrag konnte nicht gespeichert werden") {
        repo.saveJournal(e)
        if (e.mileageKm != null) {
            val current = vehicles.value?.firstOrNull { it.id == e.vehicleId }
            if (current != null && e.mileageKm > current.mileageKm) repo.updateMileage(e.vehicleId, e.mileageKm)
        }
    }
    fun deleteJournal(e: JournalEntry) = run("Löschen fehlgeschlagen") { repo.deleteJournal(e) }

    fun savePart(p: Part) = run("Teil konnte nicht gespeichert werden") {
        val dup = repo.findDuplicatePart(p)
        repo.savePart(p)
        message.value = if (dup != null) "Gespeichert – Hinweis: ähnliches Teil „${dup.name}“ existiert bereits" else "Teil gespeichert"
    }
    fun deletePart(p: Part) = run("Löschen fehlgeschlagen") { repo.deletePart(p) }

    fun setDark(v: Boolean) { viewModelScope.launch { container.setDarkTheme(v) } }
    fun setReminders(v: Boolean) { viewModelScope.launch { container.setRemindersEnabled(v) } }

    suspend fun exportJson(): String = repo.exportJson()
    fun importJson(text: String) = run("Import fehlgeschlagen (ungültige Datei?)") {
        repo.importJson(text); message.value = "Daten importiert"
    }
    fun deleteAll() = run("Löschen fehlgeschlagen") { repo.deleteAllData(); message.value = "Alle lokalen Daten gelöscht" }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = AppViewModel(container) as T
    }
}
