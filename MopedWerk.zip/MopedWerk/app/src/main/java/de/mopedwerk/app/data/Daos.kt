package de.mopedwerk.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles WHERE isArchived = :archived ORDER BY isMain DESC, brand, model")
    fun observeAll(archived: Boolean = false): Flow<List<Vehicle>>

    @Query("SELECT * FROM vehicles WHERE id = :id")
    fun observe(id: Long): Flow<Vehicle?>

    @Query("SELECT * FROM vehicles WHERE id = :id")
    suspend fun get(id: Long): Vehicle?

    @Query("SELECT * FROM vehicles")
    suspend fun getAll(): List<Vehicle>

    @Query("SELECT COUNT(*) FROM vehicles")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(vehicle: Vehicle): Long

    @Update
    suspend fun update(vehicle: Vehicle)

    @Delete
    suspend fun delete(vehicle: Vehicle)

    @Query("UPDATE vehicles SET isMain = 0")
    suspend fun clearMain()

    @Query("UPDATE vehicles SET isMain = 1 WHERE id = :id")
    suspend fun setMain(id: Long)

    @Query("UPDATE vehicles SET mileageKm = :km WHERE id = :id")
    suspend fun updateMileage(id: Long, km: Int)

    @Query("DELETE FROM vehicles")
    suspend fun deleteAll()
}

@Dao
interface MaintenanceDao {
    @Query("SELECT * FROM maintenance_tasks WHERE vehicleId = :vehicleId ORDER BY title")
    fun observeForVehicle(vehicleId: Long): Flow<List<MaintenanceTask>>

    @Query("SELECT * FROM maintenance_tasks")
    fun observeAll(): Flow<List<MaintenanceTask>>

    @Query("SELECT * FROM maintenance_tasks")
    suspend fun getAll(): List<MaintenanceTask>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: MaintenanceTask): Long

    @Update
    suspend fun update(task: MaintenanceTask)

    @Delete
    suspend fun delete(task: MaintenanceTask)
}

@Dao
interface JournalDao {
    @Query("SELECT * FROM journal_entries ORDER BY epochDay DESC, id DESC")
    fun observeAll(): Flow<List<JournalEntry>>

    @Query("SELECT * FROM journal_entries WHERE vehicleId = :vehicleId ORDER BY epochDay DESC, id DESC")
    fun observeForVehicle(vehicleId: Long): Flow<List<JournalEntry>>

    @Query(
        "SELECT * FROM journal_entries WHERE " +
            "title LIKE '%' || :q || '%' OR description LIKE '%' || :q || '%' " +
            "OR partsUsed LIKE '%' || :q || '%' OR problemAndSolution LIKE '%' || :q || '%' " +
            "ORDER BY epochDay DESC, id DESC"
    )
    fun search(q: String): Flow<List<JournalEntry>>

    @Query("SELECT * FROM journal_entries")
    suspend fun getAll(): List<JournalEntry>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: JournalEntry): Long

    @Update
    suspend fun update(entry: JournalEntry)

    @Delete
    suspend fun delete(entry: JournalEntry)
}

@Dao
interface PartDao {
    @Query("SELECT * FROM parts ORDER BY name")
    fun observeAll(): Flow<List<Part>>

    @Query("SELECT * FROM parts")
    suspend fun getAll(): List<Part>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(part: Part): Long

    @Update
    suspend fun update(part: Part)

    @Delete
    suspend fun delete(part: Part)
}
