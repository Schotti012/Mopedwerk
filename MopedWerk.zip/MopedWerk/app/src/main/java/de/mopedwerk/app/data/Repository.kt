package de.mopedwerk.app.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class BackupFile(
    val format: String = "mopedwerk-backup",
    val version: Int = 1,
    val vehicles: List<Vehicle>,
    val tasks: List<MaintenanceTask>,
    val journal: List<JournalEntry>,
    val parts: List<Part>
)

class Repository(private val db: AppDatabase) {
    private val vehicles = db.vehicleDao()
    private val maintenance = db.maintenanceDao()
    private val journal = db.journalDao()
    private val parts = db.partDao()

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true; encodeDefaults = true }

    // --- Fahrzeuge ---
    fun observeVehicles(archived: Boolean = false): Flow<List<Vehicle>> = vehicles.observeAll(archived)
    fun observeVehicle(id: Long): Flow<Vehicle?> = vehicles.observe(id)

    suspend fun saveVehicle(vehicle: Vehicle): Long = db.withTransaction {
        val isFirst = vehicles.count() == 0
        val id = vehicles.insert(if (isFirst && vehicle.id == 0L) vehicle.copy(isMain = true) else vehicle)
        id
    }

    suspend fun setMainVehicle(id: Long) = db.withTransaction {
        vehicles.clearMain()
        vehicles.setMain(id)
    }

    suspend fun setArchived(vehicle: Vehicle, archived: Boolean) {
        vehicles.update(vehicle.copy(isArchived = archived, isMain = if (archived) false else vehicle.isMain))
    }

    suspend fun deleteVehicle(vehicle: Vehicle) = vehicles.delete(vehicle)

    suspend fun updateMileage(vehicleId: Long, km: Int) = vehicles.updateMileage(vehicleId, km)

    // --- Wartung ---
    fun observeTasks(vehicleId: Long) = maintenance.observeForVehicle(vehicleId)
    fun observeAllTasks() = maintenance.observeAll()
    suspend fun saveTask(task: MaintenanceTask) = maintenance.insert(task)
    suspend fun deleteTask(task: MaintenanceTask) = maintenance.delete(task)

    /**
     * Markiert eine Wartung als erledigt und legt automatisch einen Tagebucheintrag
     * in der Fahrzeughistorie an.
     */
    suspend fun completeTask(task: MaintenanceTask, km: Int, epochDay: Long, costCents: Long = 0) =
        db.withTransaction {
            maintenance.update(task.copy(lastDoneKm = km, lastDoneEpochDay = epochDay))
            journal.insert(
                JournalEntry(
                    vehicleId = task.vehicleId,
                    epochDay = epochDay,
                    mileageKm = km,
                    title = "Wartung: ${task.title}",
                    costCents = costCents,
                    status = JournalStatus.ABGESCHLOSSEN
                )
            )
            val v = vehicles.get(task.vehicleId)
            if (v != null && km > v.mileageKm) vehicles.updateMileage(v.id, km)
        }

    // --- Tagebuch ---
    fun observeJournal() = journal.observeAll()
    fun observeJournal(vehicleId: Long) = journal.observeForVehicle(vehicleId)
    fun searchJournal(q: String) = journal.search(q)
    suspend fun saveJournal(entry: JournalEntry) = journal.insert(entry)
    suspend fun deleteJournal(entry: JournalEntry) = journal.delete(entry)

    // --- Teile ---
    fun observeParts() = parts.observeAll()
    suspend fun savePart(part: Part) = parts.insert(part)
    suspend fun deletePart(part: Part) = parts.delete(part)

    /** Findet mögliche Dubletten (gleicher Name oder gleiche Teilenummer). */
    suspend fun findDuplicatePart(candidate: Part): Part? = parts.getAll().firstOrNull {
        it.id != candidate.id && (
            it.name.equals(candidate.name, ignoreCase = true) ||
                (candidate.partNumber.isNotBlank() && it.partNumber.equals(candidate.partNumber, ignoreCase = true))
            )
    }

    // --- Export / Import / Löschen ---
    suspend fun exportJson(): String = json.encodeToString(
        BackupFile.serializer(),
        BackupFile(vehicles.getAll(), maintenance.getAll(), journal.getAll(), parts.getAll())
    )

    /** Ersetzt alle lokalen Daten durch den Inhalt der Sicherung. Wirft bei ungültiger Datei. */
    suspend fun importJson(text: String) {
        val backup = json.decodeFromString(BackupFile.serializer(), text)
        require(backup.format == "mopedwerk-backup") { "Keine MopedWerk-Sicherung" }
        db.withTransaction {
            vehicles.deleteAll()
            backup.vehicles.forEach { vehicles.insert(it) }
            backup.tasks.forEach { maintenance.insert(it) }
            backup.journal.forEach { journal.insert(it) }
            backup.parts.forEach { parts.insert(it) }
        }
    }

    suspend fun deleteAllData() = db.withTransaction { vehicles.deleteAll(); parts.getAll().forEach { parts.delete(it) } }

    suspend fun isEmpty(): Boolean = vehicles.count() == 0

    suspend fun allTasks() = maintenance.getAll()
    suspend fun allVehicles() = vehicles.getAll()
}
