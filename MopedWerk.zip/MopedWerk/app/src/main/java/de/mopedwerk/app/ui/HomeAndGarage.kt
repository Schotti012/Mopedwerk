package de.mopedwerk.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import de.mopedwerk.app.data.Vehicle
import de.mopedwerk.app.domain.CostCalculator
import de.mopedwerk.app.domain.DueState
import de.mopedwerk.app.domain.Formatting
import de.mopedwerk.app.domain.MaintenanceCalculator
import java.time.LocalDate

@Composable
fun HomeScreen(vm: AppViewModel, onOpenVehicle: (Long) -> Unit, onAddVehicle: () -> Unit, onOpenJournal: () -> Unit) {
    val vehicles by vm.vehicles.collectAsState()
    val tasks by vm.tasks.collectAsState()
    val journal by vm.allJournal.collectAsState()
    val parts by vm.parts.collectAsState()
    val list = vehicles

    if (list == null) { EmptyState("Lade …", ""); return }
    if (list.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            ScreenTitle("Willkommen bei MopedWerk")
            Text("Lege dein erstes Fahrzeug an, um Wartungen, Reparaturen und Teile zu verwalten.")
            Spacer(Modifier.height(16.dp))
            Button(onClick = onAddVehicle, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("Fahrzeug hinzufügen") }
        }
        return
    }

    val main = list.firstOrNull { it.isMain } ?: list.first()
    val today = LocalDate.now()
    val dueItems = tasks.filter { t -> list.any { it.id == t.vehicleId } }.map { t ->
        val v = list.first { it.id == t.vehicleId }
        Triple(v, t, MaintenanceCalculator.evaluate(t, v.mileageKm, today))
    }.filter { it.third.state == DueState.UEBERFAELLIG || it.third.state == DueState.BALD_FAELLIG }
        .sortedBy { if (it.third.state == DueState.UEBERFAELLIG) 0 else 1 }
    val totalSpent = CostCalculator.totalForVehicle(main.id, journal, parts)
    val monthStart = today.withDayOfMonth(1).toEpochDay()
    val monthSpent = journal.filter { it.epochDay >= monthStart }.sumOf { it.costCents }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenTitle("Werkstatt")
        MwCard(Modifier.clickable { onOpenVehicle(main.id) }) {
            Text("Hauptfahrzeug", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(main.displayName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (main.isSample) SampleBadge()
            }
            Spacer(Modifier.height(8.dp))
            LabeledRow("Kilometerstand", Formatting.km(main.mileageKm))
            LabeledRow("Status", main.status.label)
            LabeledRow("Gesamtkosten", Formatting.money(totalSpent))
        }

        SectionTitle("Fällige Wartungen")
        if (dueItems.isEmpty()) {
            Text("Nichts fällig. Wartungen ohne hinterlegtes Intervall werden hier nicht berücksichtigt.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            dueItems.forEach { (v, t, info) ->
                MwCard(Modifier.padding(bottom = 8.dp).clickable { onOpenVehicle(v.id) }) {
                    Text(t.title, fontWeight = FontWeight.SemiBold)
                    Text("${v.displayName} · ${info.state.label}",
                        color = if (info.state == DueState.UEBERFAELLIG) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.primary)
                }
            }
        }

        SectionTitle("Ausgaben")
        MwCard {
            LabeledRow("Dieser Monat (Tagebuch)", Formatting.money(monthSpent))
        }

        SectionTitle("Zuletzt im Tagebuch")
        val recent = journal.take(3)
        if (recent.isEmpty()) Text("Noch keine Einträge.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        recent.forEach { e ->
            MwCard(Modifier.padding(bottom = 8.dp).clickable { onOpenJournal() }) {
                Text(e.title, fontWeight = FontWeight.SemiBold)
                Text(Formatting.date(e.epochDay), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onOpenJournal, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Zum Schrauber-Tagebuch") }
    }
}

@Composable
fun GarageScreen(vm: AppViewModel, onOpenVehicle: (Long) -> Unit) {
    val vehicles by vm.vehicles.collectAsState()
    val archived by vm.archivedVehicles.collectAsState()
    var showForm by remember { mutableStateOf(false) }
    var showArchived by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showForm = true }, containerColor = MaterialTheme.colorScheme.primary) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text("  Fahrzeug")
            }
        }
    ) { padding ->
        val list = vehicles
        Column(Modifier.padding(padding).padding(horizontal = 16.dp)) {
            ScreenTitle("Meine Garage")
            when {
                list == null -> EmptyState("Lade …", "")
                list.isEmpty() && archived.isEmpty() ->
                    EmptyState("Noch kein Fahrzeug", "Tippe auf „Fahrzeug“, um dein erstes Moped anzulegen.")
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list, key = { it.id }) { v -> VehicleCard(v) { onOpenVehicle(v.id) } }
                    if (archived.isNotEmpty()) {
                        item {
                            OutlinedButton(onClick = { showArchived = !showArchived }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (showArchived) "Archiv ausblenden" else "Archiv anzeigen (${archived.size})")
                            }
                        }
                        if (showArchived) items(archived, key = { -it.id }) { v -> VehicleCard(v) { onOpenVehicle(v.id) } }
                    }
                }
            }
        }
    }

    if (showForm) VehicleForm(null, onDismiss = { showForm = false }, onSave = { vm.saveVehicle(it) })
}

@Composable
private fun VehicleCard(v: Vehicle, onClick: () -> Unit) {
    MwCard(Modifier.clickable { onClick() }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(v.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (v.isMain) Text("★ Haupt", color = MaterialTheme.colorScheme.primary)
            if (v.isSample) SampleBadge()
        }
        Text(listOfNotNull(v.year?.toString(), v.type, v.displacementCcm?.let { "$it ccm" }).joinToString(" · "),
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        Text("${Formatting.km(v.mileageKm)} · ${v.status.label}")
    }
}
