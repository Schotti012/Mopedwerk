package de.mopedwerk.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import de.mopedwerk.app.ui.AppViewModel
import de.mopedwerk.app.ui.GarageScreen
import de.mopedwerk.app.ui.HomeScreen
import de.mopedwerk.app.ui.JournalList
import de.mopedwerk.app.ui.MopedWerkTheme
import de.mopedwerk.app.ui.PartsList
import de.mopedwerk.app.ui.ProfileScreen
import de.mopedwerk.app.ui.VehicleDetailScreen
import de.mopedwerk.app.ui.VehicleForm

private data class Dest(val route: String, val label: String, val icon: ImageVector)

private val destinations = listOf(
    Dest("home", "Home", Icons.Filled.Home),
    Dest("garage", "Garage", Icons.Filled.TwoWheeler),
    Dest("schrauben", "Schrauben", Icons.Filled.Build),
    Dest("teile", "Teile", Icons.Filled.Settings),
    Dest("profil", "Profil", Icons.Filled.Person)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as MopedWerkApp).container
        setContent {
            val vm: AppViewModel = viewModel(factory = AppViewModel.Factory(container))
            val dark by vm.darkTheme.collectAsState()
            MopedWerkTheme(dark = dark) {
                Surface(Modifier.fillMaxSize()) { MopedWerkRoot(vm) }
            }
        }
    }
}

@Composable
private fun MopedWerkRoot(vm: AppViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route
    val snackbar = remember { SnackbarHostState() }
    val message by vm.message.collectAsState()
    var showAddVehicle by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let { snackbar.showSnackbar(it); vm.message.value = null }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar {
                destinations.forEach { d ->
                    val selected = current == d.route || (d.route == "garage" && current?.startsWith("vehicle/") == true)
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            nav.navigate(d.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = false }
                                launchSingleTop = true
                            }
                        },
                        icon = { Icon(d.icon, contentDescription = d.label) },
                        label = { Text(d.label) },
                        colors = NavigationBarItemDefaults.colors()
                    )
                }
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
            composable("home") {
                HomeScreen(
                    vm,
                    onOpenVehicle = { nav.navigate("vehicle/$it") },
                    onAddVehicle = { showAddVehicle = true },
                    onOpenJournal = { nav.navigate("schrauben") { launchSingleTop = true } }
                )
            }
            composable("garage") { GarageScreen(vm) { nav.navigate("vehicle/$it") } }
            composable("schrauben") { JournalList(vm) }
            composable("teile") { PartsList(vm) }
            composable("profil") { ProfileScreen(vm) }
            composable("vehicle/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                VehicleDetailScreen(vm, entry.arguments?.getLong("id") ?: -1L) { nav.popBackStack() }
            }
        }
    }

    if (showAddVehicle) VehicleForm(null, onDismiss = { showAddVehicle = false }, onSave = { vm.saveVehicle(it) })
}
