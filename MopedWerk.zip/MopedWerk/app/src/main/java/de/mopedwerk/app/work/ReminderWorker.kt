package de.mopedwerk.app.work

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import de.mopedwerk.app.MopedWerkApp
import de.mopedwerk.app.R
import de.mopedwerk.app.domain.DueState
import de.mopedwerk.app.domain.MaintenanceCalculator
import kotlinx.coroutines.flow.first
import java.time.LocalDate

/** Prüft täglich im Hintergrund, ob Wartungen fällig oder überfällig sind. */
class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? MopedWerkApp ?: return Result.success()
        if (!app.container.remindersEnabled.first()) return Result.success()

        val vehicles = app.container.repository.allVehicles().filter { !it.isArchived }.associateBy { it.id }
        val today = LocalDate.now()
        val due = app.container.repository.allTasks().mapNotNull { task ->
            val v = vehicles[task.vehicleId] ?: return@mapNotNull null
            val info = MaintenanceCalculator.evaluate(task, v.mileageKm, today)
            if (info.state == DueState.UEBERFAELLIG || info.state == DueState.BALD_FAELLIG) {
                "${v.displayName}: ${task.title} (${info.state.label})"
            } else null
        }
        if (due.isEmpty() || !canNotify()) return Result.success()

        val text = due.take(5).joinToString("\n")
        val notification = Notification.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("${due.size} Wartung(en) fällig")
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentText(due.first())
            .build()
        applicationContext.getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification)
        return Result.success()
    }

    private fun canNotify(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    companion object {
        const val CHANNEL_ID = "wartung"
        const val NOTIFICATION_ID = 1001
    }
}
