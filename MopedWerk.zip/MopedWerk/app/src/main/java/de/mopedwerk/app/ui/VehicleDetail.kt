package de.mopedwerk.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import de.mopedwerk.app.data.MaintenanceTask
import de.mopedwerk.app.data.Vehicle
import de.mopedwerk.app.domain.CostCalculator
import de.mopedwerk.app.domain.DueState
import de.mopedwerk.app.domain.Formatting
import de.mopedwerk.app.domain.MaintenanceCalculator
import java.time.LocalDate

private val tabs = listOf("Übersicht", "Wartung", "Tagebuch", "Teile")

@Composable
fun VehicleDetailScreen(vm: AppViewModel, vehicleId: Long, onBack: () -> Unit) {
    val vehicles by vm.vehicles.collectAsState()
    val archived by vm.archivedVehicles.collectAsState()
    val vehicle = (vehicles.orEmpty() + archived).firstOrNull { it.id == vehicleId }
    var tab by remember { mutableStateOf(0) }

    if (vehicle == null) {
        EmptyState("Fahrzeug nicht gefunden", "Es wurde eventuell gelöscht.")
        return
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = onBack) { Text("‹ Zurück") }
        }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(vehicle.displayName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            if (vehicle.isSample) SampleBadge()
        }
        TabRow(selectedTabIndex = tab) {
            tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        when (tab) {
            0 -> OverviewTab(vm, vehicle, onBack)
            1 -> MaintenanceTab(vm, vehicle)
            2 -> JournalList(vm, vehicleFilter = vehicle.id, showTitle = false)
            else -> PartsList(vm, vehicleFilter = vehicle.id, showTitle = false)
        }
    }
}

@Composable
private fun OverviewTab(vm: AppViewModel, v: Vehicle, onBack: () -> Unit) {
    val journal by vm.allJournal.collectAsState()
    val parts by vm.parts.collectAsState()
    var edit by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val total = CostCalculator.totalForVehicle(v.id, journal, parts)
    val planned = CostCalculator.plannedForVehicle(v.id, parts)

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
        MwCard {
            LabeledRow("Typ", v.type)
            v.year?.let { LabeledRow("Baujahr", it.toString()) }
            v.displacementCcm?.let { LabeledRow("Hubraum", "$it ccm") }
            if (v.vin.isNotBlank()) LabeledRow("Fahrgestellnr.", v.vin)
            if (v.engineCode.isNotBlank()) LabeledRow("Motorkennung", v.engineCode)
            LabeledRow("Kilometerstand", Formatting.km(v.mileageKm))
            LabeledRow("Status", v.status.label)
            if (v.notes.isNotBlank()) Text(v.notes, modifier = Modifier.padding(top = 8.dp))
        }
        SectionTitle("Kosten")
        MwCard {
            v.purchasePriceCents?.let { LabeledRow("Kaufpreis", Formatting.money(it)) }
            LabeledRow("Ausgaben (Tagebuch + Teile)", Formatting.money(total))
            LabeledRow("Geplante Teile", Formatting.money(planned))
        }
        SectionTitle("Aktionen")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { edit = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Bearbeiten") }
            if (!v.isArchived) {
                OutlinedButton(onClick = { vm.setMain(v.id) }, enabled = !v.isMain,
                    modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text(if (v.isMain) "Ist Hauptfahrzeug" else "Als Hauptfahrzeug markieren")
                }
            }
            OutlinedButton(onClick = { vm.archive(v, !v.isArchived) }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(if (v.isArchived) "Aus Archiv wiederherstellen" else "Archivieren")
            }
            OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("Löschen", color = MaterialTheme.colorScheme.error)
            }
        }
    }
    if (edit) VehicleForm(v, onDismiss = { edit = false }, onSave = { vm.saveVehicle(it) })
    if (confirmDelete) ConfirmDialog(
        "Fahrzeug löschen?",
        "„${v.displayName}“ mit allen Wartungen und Tagebucheinträgen wird unwiderruflich gelöscht.",
        "Löschen", onConfirm = { vm.deleteVehicle(v); onBack() }, onDismiss = { confirmDelete = false }
    )
}

@Composable
private fun MaintenanceTab(vm: AppViewModel, v: Vehicle) {
    val allTasks by vm.tasks.collectAsState()
    val tasks = allTasks.filter { it.vehicleId == v.id }
    var editing by remember { mutableStateOf<MaintenanceTask?>(null) }
    var adding by remember { mutableStateOf(false) }
    var completing by remember { mutableStateOf<MaintenanceTask?>(null) }
    val today = LocalDate.now()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Wartungspunkt hinzufügen") }
        if (tasks.isEmpty()) {
            EmptyState("Keine Wartungspunkte", "Lege Wartungspunkte mit eigenen Intervallen an.")
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 12.dp)) {
            items(tasks, key = { it.id }) { t ->
                val info = MaintenanceCalculator.evaluate(t, v.mileageKm, today)
                MwCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(t.title, fontWeight = FontWeight.SemiBold)
                        if (t.isSample) SampleBadge()
                    }
                    Text(info.state.label, color = when (info.state) {
                        DueState.UEBERFAELLIG -> MaterialTheme.colorScheme.error
                        DueState.BALD_FAELLIG -> MaterialTheme.colorScheme.primary
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    })
                    info.nextDueKm?.let { LabeledRow("Nächste Fälligkeit", Formatting.km(it)) }
                    info.nextDueDate?.let { LabeledRow("Nächstes Datum", Formatting.date(it)) }
                    t.lastDoneEpochDay?.let { LabeledRow("Zuletzt erledigt", Formatting.date(it)) }
                    if (t.intervalKm != null || t.intervalMonths != null) {
                        Text(
                            if (t.intervalVerified) "Intervall: vom Nutzer als geprüft markiert"
                            else "Intervall: nicht verifiziert (selbst eingetragen)",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text("Kein verlässliches Intervall hinterlegt – bitte im Handbuch nachsehen.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(onClick = { completing = t }) { Text("Erledigt") }
                        TextButton(onClick = { editing = t }) { Text("Bearbeiten") }
                        TextButton(onClick = { vm.deleteTask(t) }) { Text("Löschen") }
                    }
                }
            }
        }
    }

    if (adding) TaskForm(v.id, null, { adding = false }) { vm.saveTask(it) }
    editing?.let { t -> TaskForm(v.id, t, { editing = null }) { vm.saveTask(it) } }
    completing?.let { t ->
        CompleteDialog(v.mileageKm, onDismiss = { completing = null }) { km, cents ->
            vm.completeTask(t, km, LocalDate.now().toEpochDay(), cents)
        }
    }
}

@Composable
private fun CompleteDialog(currentKm: Int, onDismiss: () -> Unit, onConfirm: (Int, Long) -> Unit) {
    var km by remember { mutableStateOf(currentKm.toString()) }
    var cost by remember { mutableStateOf("") }
    val kmInt = km.toIntOrNull()
    val cents = Formatting.parseMoneyToCents(cost)
    var showErrors by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Wartung erledigt") },
        text = {
            Column {
                Text("Wird heute eingetragen und erscheint automatisch im Tagebuch.")
                FormField("Kilometerstand", km, { km = it }, numeric = true,
                    error = if (showErrors && (kmInt == null || kmInt < 0)) "Ungültiger Kilometerstand" else null)
                FormField("Kosten (€, optional)", cost, { cost = it }, decimal = true,
                    error = if (showErrors && cents == null) "Ungültiger Betrag" else null)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                showErrors = true
                if (kmInt != null && kmInt >= 0 && cents != null) { onConfirm(kmInt, cents); onDismiss() }
            }) { Text("Eintragen") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}
