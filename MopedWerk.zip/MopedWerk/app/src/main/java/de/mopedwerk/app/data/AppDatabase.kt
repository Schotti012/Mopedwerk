package de.mopedwerk.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Vehicle::class, MaintenanceTask::class, JournalEntry::class, Part::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao
    abstract fun maintenanceDao(): MaintenanceDao
    abstract fun journalDao(): JournalDao
    abstract fun partDao(): PartDao

    companion object {
        const val NAME = "mopedwerk.db"

        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, NAME)
                // Migrationen werden ab Version 2 explizit ergänzt (siehe README).
                .build()
    }
}
