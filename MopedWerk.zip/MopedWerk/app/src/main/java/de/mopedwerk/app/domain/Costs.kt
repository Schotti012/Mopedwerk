package de.mopedwerk.app.domain

import de.mopedwerk.app.data.JournalEntry
import de.mopedwerk.app.data.Part
import de.mopedwerk.app.data.PartStatus

object CostCalculator {
    /** Teile zählen als Ausgabe, sobald sie bestellt, geliefert oder verbaut sind. */
    private val spentStatuses = setOf(PartStatus.BESTELLT, PartStatus.GELIEFERT, PartStatus.VERBAUT)

    fun partCostCents(part: Part): Long = part.priceCents * part.quantity

    fun totalForVehicle(vehicleId: Long, journal: List<JournalEntry>, parts: List<Part>): Long {
        val journalSum = journal.filter { it.vehicleId == vehicleId }.sumOf { it.costCents }
        val partsSum = parts.filter { it.vehicleId == vehicleId && it.status in spentStatuses }
            .sumOf { partCostCents(it) }
        return journalSum + partsSum
    }

    /** Geplante (noch nicht gekaufte) Teile eines Fahrzeugs. */
    fun plannedForVehicle(vehicleId: Long, parts: List<Part>): Long =
        parts.filter { it.vehicleId == vehicleId && it.status == PartStatus.GEPLANT }
            .sumOf { partCostCents(it) }
}
