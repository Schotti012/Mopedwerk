package de.mopedwerk.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Orange = Color(0xFFFF6D00)
val Anthracite = Color(0xFF2B2B2B)
val Black = Color(0xFF121212)

private val DarkColors = darkColorScheme(
    primary = Orange,
    onPrimary = Color.Black,
    secondary = Color(0xFFFFB74D),
    background = Black,
    onBackground = Color.White,
    surface = Anthracite,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF3A3A3A),
    onSurfaceVariant = Color(0xFFD0D0D0),
    error = Color(0xFFFF5252)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFFD65A00),
    onPrimary = Color.White,
    secondary = Color(0xFF8D4B00),
    background = Color(0xFFF6F6F6),
    onBackground = Color(0xFF1A1A1A),
    surface = Color.White,
    onSurface = Color(0xFF1A1A1A),
    surfaceVariant = Color(0xFFE8E8E8),
    onSurfaceVariant = Color(0xFF444444),
    error = Color(0xFFB00020)
)

@Composable
fun MopedWerkTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
