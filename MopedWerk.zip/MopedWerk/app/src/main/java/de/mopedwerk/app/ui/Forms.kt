package de.mopedwerk.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.Alignment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import de.mopedwerk.app.data.JournalEntry
import de.mopedwerk.app.data.JournalStatus
import de.mopedwerk.app.data.MaintenanceTask
import de.mopedwerk.app.data.Part
import de.mopedwerk.app.data.PartCategory
import de.mopedwerk.app.data.PartStatus
import de.mopedwerk.app.data.Vehicle
import de.mopedwerk.app.data.VehicleStatus
import de.mopedwerk.app.domain.Formatting
import java.time.LocalDate

@Composable
private fun FormDialog(title: String, onDismiss: () -> Unit, onSave: () -> Unit, content: @Composable () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { content() } },
        confirmButton = { TextButton(onClick = onSave) { Text("Speichern") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

@Composable
fun VehicleForm(initial: Vehicle?, onDismiss: () -> Unit, onSave: (Vehicle) -> Unit) {
    var brand by remember { mutableStateOf(initial?.brand ?: "") }
    var model by remember { mutableStateOf(initial?.model ?: "") }
    var year by remember { mutableStateOf(initial?.year?.toString() ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: "Moped") }
    var ccm by remember { mutableStateOf(initial?.displacementCcm?.toString() ?: "") }
    var vin by remember { mutableStateOf(initial?.vin ?: "") }
    var engine by remember { mutableStateOf(initial?.engineCode ?: "") }
    var km by remember { mutableStateOf(initial?.mileageKm?.toString() ?: "0") }
    var status by remember { mutableStateOf(initial?.status ?: VehicleStatus.FAHRBEREIT) }
    var price by remember { mutableStateOf(initial?.purchasePriceCents?.let { (it / 100.0).toString().replace('.', ',') } ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var showErrors by remember { mutableStateOf(false) }

    val yearInt = year.toIntOrNull()
    val yearError = if (year.isNotBlank() && (yearInt == null || yearInt !in 1900..LocalDate.now().year + 1)) "Ungültiges Baujahr" else null
    val kmInt = km.toIntOrNull()
    val kmError = if (kmInt == null || kmInt < 0) "Bitte gültigen Kilometerstand eingeben" else null
    val ccmError = if (ccm.isNotBlank() && ccm.toIntOrNull() == null) "Nur Zahlen" else null
    val priceCents = Formatting.parseMoneyToCents(price)
    val priceError = if (priceCents == null) "Ungültiger Betrag" else null
    val brandError = if (brand.isBlank()) "Marke ist erforderlich" else null
    val modelError = if (model.isBlank()) "Modell ist erforderlich" else null

    FormDialog(
        title = if (initial == null) "Fahrzeug hinzufügen" else "Fahrzeug bearbeiten",
        onDismiss = onDismiss,
        onSave = {
            showErrors = true
            val anyError = listOf(brandError, modelError, yearError, kmError, ccmError, priceError).any { it != null }
            if (!anyError) {
                onSave(
                    (initial ?: Vehicle(brand = "", model = "")).copy(
                        brand = brand.trim(), model = model.trim(), year = yearInt, type = type.trim().ifBlank { "Moped" },
                        displacementCcm = ccm.toIntOrNull(), vin = vin.trim(), engineCode = engine.trim(),
                        mileageKm = kmInt ?: 0, status = status,
                        purchasePriceCents = if (price.isBlank()) null else priceCents,
                        notes = notes.trim(), isSample = false
                    )
                )
                onDismiss()
            }
        }
    ) {
        FormField("Marke", brand, { brand = it }, error = if (showErrors) brandError else null)
        FormField("Modell", model, { model = it }, error = if (showErrors) modelError else null)
        FormField("Baujahr", year, { year = it }, numeric = true, error = if (showErrors) yearError else null)
        FormField("Fahrzeugtyp (Moped, Mofa, Roller …)", type, { type = it })
        FormField("Hubraum (ccm)", ccm, { ccm = it }, numeric = true, error = if (showErrors) ccmError else null)
        FormField("Fahrgestellnummer", vin, { vin = it })
        FormField("Motorkennung", engine, { engine = it })
        FormField("Kilometerstand", km, { km = it }, numeric = true, error = if (showErrors) kmError else null)
        DropdownField("Projektstatus", VehicleStatus.entries, status, { it.label }) { status = it }
        FormField("Kaufpreis (€)", price, { price = it }, decimal = true, error = if (showErrors) priceError else null)
        FormField("Notizen", notes, { notes = it }, singleLine = false)
    }
}

@Composable
fun TaskForm(vehicleId: Long, initial: MaintenanceTask?, onDismiss: () -> Unit, onSave: (MaintenanceTask) -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var intervalKm by remember { mutableStateOf(initial?.intervalKm?.toString() ?: "") }
    var intervalMonths by remember { mutableStateOf(initial?.intervalMonths?.toString() ?: "") }
    var lastKm by remember { mutableStateOf(initial?.lastDoneKm?.toString() ?: "") }
    var lastDate by remember { mutableStateOf(initial?.lastDoneEpochDay?.let { Formatting.date(it) } ?: "") }
    var verified by remember { mutableStateOf(initial?.intervalVerified ?: false) }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var showErrors by remember { mutableStateOf(false) }

    val titleError = if (title.isBlank()) "Bezeichnung ist erforderlich" else null
    val ikmError = if (intervalKm.isNotBlank() && (intervalKm.toIntOrNull() ?: 0) <= 0) "Positive Zahl eingeben" else null
    val imError = if (intervalMonths.isNotBlank() && (intervalMonths.toIntOrNull() ?: 0) <= 0) "Positive Zahl eingeben" else null
    val lkmError = if (lastKm.isNotBlank() && lastKm.toIntOrNull() == null) "Nur Zahlen" else null
    val parsedDate = if (lastDate.isBlank()) null else Formatting.parseDate(lastDate)
    val dateError = if (lastDate.isNotBlank() && parsedDate == null) "Format TT.MM.JJJJ" else null

    FormDialog(
        title = if (initial == null) "Wartungspunkt hinzufügen" else "Wartungspunkt bearbeiten",
        onDismiss = onDismiss,
        onSave = {
            showErrors = true
            if (listOf(titleError, ikmError, imError, lkmError, dateError).all { it == null }) {
                onSave(
                    (initial ?: MaintenanceTask(vehicleId = vehicleId, title = "")).copy(
                        title = title.trim(),
                        intervalKm = intervalKm.toIntOrNull(), intervalMonths = intervalMonths.toIntOrNull(),
                        lastDoneKm = lastKm.toIntOrNull(), lastDoneEpochDay = parsedDate?.toEpochDay(),
                        intervalVerified = verified, notes = notes.trim(), isSample = false
                    )
                )
                onDismiss()
            }
        }
    ) {
        Text("Intervalle trägst du selbst ein – die App liefert keine Herstellerwerte. Ohne Intervall bleibt der Punkt als „Kein Intervall hinterlegt“ markiert.")
        FormField("Bezeichnung", title, { title = it }, error = if (showErrors) titleError else null)
        FormField("Intervall in km (optional)", intervalKm, { intervalKm = it }, numeric = true, error = if (showErrors) ikmError else null)
        FormField("Intervall in Monaten (optional)", intervalMonths, { intervalMonths = it }, numeric = true, error = if (showErrors) imError else null)
        FormField("Zuletzt erledigt bei km", lastKm, { lastKm = it }, numeric = true, error = if (showErrors) lkmError else null)
        FormField("Zuletzt erledigt am (TT.MM.JJJJ)", lastDate, { lastDate = it }, error = if (showErrors) dateError else null)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = verified, onCheckedChange = { verified = it })
            Text("Intervall aus Handbuch/verlässlicher Quelle geprüft")
        }
        FormField("Notizen", notes, { notes = it }, singleLine = false)
    }
}

@Composable
fun JournalForm(
    vehicles: List<Vehicle>,
    defaultVehicleId: Long?,
    initial: JournalEntry?,
    onDismiss: () -> Unit,
    onSave: (JournalEntry) -> Unit
) {
    var vehicleId by remember { mutableStateOf(initial?.vehicleId ?: defaultVehicleId ?: vehicles.firstOrNull()?.id) }
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var date by remember { mutableStateOf(Formatting.date(initial?.epochDay ?: LocalDate.now().toEpochDay())) }
    var km by remember { mutableStateOf(initial?.mileageKm?.toString() ?: "") }
    var description by remember { mutableStateOf(initial?.description ?: "") }
    var parts by remember { mutableStateOf(initial?.partsUsed ?: "") }
    var tools by remember { mutableStateOf(initial?.toolsUsed ?: "") }
    var minutes by remember { mutableStateOf(initial?.workMinutes?.takeIf { it > 0 }?.toString() ?: "") }
    var cost by remember { mutableStateOf(initial?.costCents?.takeIf { it > 0 }?.let { (it / 100.0).toString().replace('.', ',') } ?: "") }
    var status by remember { mutableStateOf(initial?.status ?: JournalStatus.ABGESCHLOSSEN) }
    var solution by remember { mutableStateOf(initial?.problemAndSolution ?: "") }
    var showErrors by remember { mutableStateOf(false) }

    val titleError = if (title.isBlank()) "Titel ist erforderlich" else null
    val parsedDate = Formatting.parseDate(date)
    val dateError = if (parsedDate == null) "Format TT.MM.JJJJ" else null
    val kmError = if (km.isNotBlank() && km.toIntOrNull() == null) "Nur Zahlen" else null
    val minError = if (minutes.isNotBlank() && minutes.toIntOrNull() == null) "Nur Zahlen" else null
    val costCents = Formatting.parseMoneyToCents(cost)
    val costError = if (costCents == null) "Ungültiger Betrag" else null
    val vehicleError = if (vehicleId == null) "Bitte zuerst ein Fahrzeug in der Garage anlegen" else null

    FormDialog(
        title = if (initial == null) "Neuer Tagebucheintrag" else "Eintrag bearbeiten",
        onDismiss = onDismiss,
        onSave = {
            showErrors = true
            if (listOf(titleError, dateError, kmError, minError, costError, vehicleError).all { it == null }) {
                onSave(
                    (initial ?: JournalEntry(vehicleId = vehicleId!!, epochDay = 0, title = "")).copy(
                        vehicleId = vehicleId!!, epochDay = parsedDate!!.toEpochDay(), mileageKm = km.toIntOrNull(),
                        title = title.trim(), description = description.trim(), partsUsed = parts.trim(),
                        toolsUsed = tools.trim(), workMinutes = minutes.toIntOrNull() ?: 0,
                        costCents = costCents ?: 0, status = status, problemAndSolution = solution.trim(), isSample = false
                    )
                )
                onDismiss()
            }
        }
    ) {
        if (vehicles.isNotEmpty()) {
            val selected = vehicles.firstOrNull { it.id == vehicleId } ?: vehicles.first()
            DropdownField("Fahrzeug", vehicles, selected, { it.displayName }) { vehicleId = it.id }
        } else if (showErrors) {
            Text(vehicleError ?: "")
        }
        FormField("Titel / durchgeführte Arbeit", title, { title = it }, error = if (showErrors) titleError else null)
        FormField("Datum (TT.MM.JJJJ)", date, { date = it }, error = if (showErrors) dateError else null)
        FormField("Kilometerstand (optional)", km, { km = it }, numeric = true, error = if (showErrors) kmError else null)
        DropdownField("Status", JournalStatus.entries, status, { it.label }) { status = it }
        FormField("Beschreibung / Notizen", description, { description = it }, singleLine = false)
        FormField("Verwendete Teile", parts, { parts = it })
        FormField("Verwendete Werkzeuge", tools, { tools = it })
        FormField("Arbeitszeit (Minuten)", minutes, { minutes = it }, numeric = true, error = if (showErrors) minError else null)
        FormField("Kosten (€)", cost, { cost = it }, decimal = true, error = if (showErrors) costError else null)
        FormField("Problem und Lösung", solution, { solution = it }, singleLine = false)
    }
}

@Composable
fun PartForm(vehicles: List<Vehicle>, initial: Part?, onDismiss: () -> Unit, onSave: (Part) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: PartCategory.MOTOR) }
    var manufacturer by remember { mutableStateOf(initial?.manufacturer ?: "") }
    var number by remember { mutableStateOf(initial?.partNumber ?: "") }
    var price by remember { mutableStateOf(initial?.priceCents?.takeIf { it > 0 }?.let { (it / 100.0).toString().replace('.', ',') } ?: "") }
    var shop by remember { mutableStateOf(initial?.shop ?: "") }
    var url by remember { mutableStateOf(initial?.shopUrl ?: "") }
    var qty by remember { mutableStateOf((initial?.quantity ?: 1).toString()) }
    var status by remember { mutableStateOf(initial?.status ?: PartStatus.GEPLANT) }
    var confirmed by remember { mutableStateOf(initial?.compatibilityConfirmed ?: false) }
    var vehicleId by remember { mutableStateOf(initial?.vehicleId) }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var showErrors by remember { mutableStateOf(false) }

    val nameError = if (name.isBlank()) "Name ist erforderlich" else null
    val qtyInt = qty.toIntOrNull()
    val qtyError = if (qtyInt == null || qtyInt < 0) "Ungültige Menge" else null
    val priceCents = Formatting.parseMoneyToCents(price)
    val priceError = if (priceCents == null) "Ungültiger Betrag" else null

    FormDialog(
        title = if (initial == null) "Teil hinzufügen" else "Teil bearbeiten",
        onDismiss = onDismiss,
        onSave = {
            showErrors = true
            if (listOf(nameError, qtyError, priceError).all { it == null }) {
                onSave(
                    (initial ?: Part(name = "")).copy(
                        name = name.trim(), category = category, manufacturer = manufacturer.trim(),
                        partNumber = number.trim(), priceCents = priceCents ?: 0, shop = shop.trim(),
                        shopUrl = url.trim(), quantity = qtyInt ?: 1, status = status,
                        compatibilityConfirmed = confirmed, vehicleId = vehicleId, notes = notes.trim(), isSample = false
                    )
                )
                onDismiss()
            }
        }
    ) {
        FormField("Name", name, { name = it }, error = if (showErrors) nameError else null)
        DropdownField("Kategorie", PartCategory.entries, category, { it.label }) { category = it }
        DropdownField("Status", PartStatus.entries, status, { it.label }) { status = it }
        val vehicleOptions: List<Vehicle?> = listOf<Vehicle?>(null) + vehicles
        DropdownField("Fahrzeug", vehicleOptions, vehicleOptions.firstOrNull { it?.id == vehicleId },
            { it?.displayName ?: "Keinem Fahrzeug zugeordnet" }) { vehicleId = it?.id }
        FormField("Hersteller", manufacturer, { manufacturer = it })
        FormField("Teilenummer", number, { number = it })
        FormField("Preis pro Stück (€)", price, { price = it }, decimal = true, error = if (showErrors) priceError else null)
        FormField("Menge", qty, { qty = it }, numeric = true, error = if (showErrors) qtyError else null)
        FormField("Händler", shop, { shop = it })
        FormField("Link zum Shop", url, { url = it })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = confirmed, onCheckedChange = { confirmed = it })
            Text("Kompatibilität mit dem Fahrzeug bestätigt")
        }
        FormField("Notizen", notes, { notes = it }, singleLine = false)
    }
}
