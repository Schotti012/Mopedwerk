package de.mopedwerk.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import de.mopedwerk.app.data.AppDatabase
import de.mopedwerk.app.data.Repository
import de.mopedwerk.app.data.SampleData
import de.mopedwerk.app.work.ReminderWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

private val Context.dataStore by preferencesDataStore(name = "settings")

/** Einfacher Dependency-Container (manuelle DI) – hält Datenbank und Repository. */
class AppContainer(context: Context) {
    val database: AppDatabase = AppDatabase.create(context)
    val repository = Repository(database)
    private val store = context.applicationContext.dataStore

    private val darkKey = booleanPreferencesKey("dark_theme")
    private val sampleKey = booleanPreferencesKey("sample_seeded")
    private val remindersKey = booleanPreferencesKey("reminders_enabled")

    val darkTheme: Flow<Boolean> = store.data.map { it[darkKey] ?: true }
    val remindersEnabled: Flow<Boolean> = store.data.map { it[remindersKey] ?: true }

    suspend fun setDarkTheme(value: Boolean) { store.edit { it[darkKey] = value } }
    suspend fun setRemindersEnabled(value: Boolean) { store.edit { it[remindersKey] = value } }

    /** Legt beim allerersten Start Beispieldaten an (nur einmal). */
    suspend fun seedSampleDataOnce() {
        var alreadySeeded = false
        store.edit { prefs ->
            alreadySeeded = prefs[sampleKey] ?: false
            prefs[sampleKey] = true
        }
        if (!alreadySeeded && repository.isEmpty()) SampleData.insertInto(repository)
    }
}

class MopedWerkApp : Application() {
    lateinit var container: AppContainer
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        createNotificationChannel()
        scheduleReminders()
        appScope.launch { container.seedSampleDataOnce() }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            ReminderWorker.CHANNEL_ID,
            getString(R.string.channel_reminders),
            NotificationManager.IMPORTANCE_DEFAULT
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun scheduleReminders() {
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "wartungs_erinnerung", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }
}
