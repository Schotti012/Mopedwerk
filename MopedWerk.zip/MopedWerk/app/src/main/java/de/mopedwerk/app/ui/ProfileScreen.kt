package de.mopedwerk.app.ui

import android.Manifest
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ProfileScreen(vm: AppViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dark by vm.darkTheme.collectAsState()
    val reminders by vm.remindersEnabled.collectAsState()
    var confirmDeleteAll by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) scope.launch {
            try {
                val text = vm.exportJson()
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                        ?: error("Datei konnte nicht geöffnet werden")
                }
                vm.message.value = "Sicherung gespeichert"
            } catch (e: Exception) {
                vm.message.value = "Export fehlgeschlagen: ${e.message}"
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            try {
                val text = withContext(Dispatchers.IO) { readText(context, uri) }
                vm.importJson(text)
            } catch (e: Exception) {
                vm.message.value = "Import fehlgeschlagen: ${e.message}"
            }
        }
    }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenTitle("Profil & Einstellungen")

        SectionTitle("Darstellung")
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Dunkles Design")
            Switch(checked = dark, onCheckedChange = { vm.setDark(it) })
        }

        SectionTitle("Erinnerungen")
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Wartungserinnerungen")
            Switch(checked = reminders, onCheckedChange = {
                vm.setReminders(it)
                if (it && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            })
        }
        Text("Die App prüft einmal täglich im Hintergrund, ob Wartungen fällig sind.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        SectionTitle("Daten")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { exportLauncher.launch("mopedwerk-sicherung.json") },
                modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Daten exportieren (JSON)") }
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
                modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Daten importieren") }
            OutlinedButton(onClick = { confirmDeleteAll = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("Alle lokalen Daten löschen", color = MaterialTheme.colorScheme.error)
            }
        }
        Text("Ein Import ersetzt alle aktuell gespeicherten Daten.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp))

        SectionTitle("Datenschutz")
        Text(
            "Alle Daten liegen ausschließlich lokal auf diesem Gerät. Es gibt kein Benutzerkonto, " +
                "keine Analyse- oder Tracking-Funktionen und keine Übertragung von Daten oder Fotos. " +
                "Die einzige Berechtigung ist die Benachrichtigung für Wartungserinnerungen."
        )

        SectionTitle("Über MopedWerk")
        Text("Version 0.1.0 (Kern-Version). Angaben zu Wartungsintervallen und Teilekompatibilität stammen " +
            "ausschließlich von dir und sind nicht von der App geprüft.")
    }

    if (confirmDeleteAll) ConfirmDialog(
        "Alle Daten löschen?",
        "Fahrzeuge, Wartungen, Tagebuch und Teile werden unwiderruflich von diesem Gerät gelöscht. Erstelle vorher am besten eine Sicherung.",
        "Alles löschen", onConfirm = { vm.deleteAll() }, onDismiss = { confirmDeleteAll = false }
    )
}

private fun readText(context: Context, uri: Uri): String =
    context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
        ?: error("Datei konnte nicht gelesen werden")
